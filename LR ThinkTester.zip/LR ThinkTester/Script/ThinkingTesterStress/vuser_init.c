vuser_init()
{
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");
	
	web_reg_find("Text=Contact List App",LAST);
	
	

	web_url("thinking-tester-contact-list.herokuapp.com", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	web_image_check("Image check","Src=/img/thinkingTesterLogo.png");

	/* Home page */

	web_add_cookie("pglt-edgeChromium-ntp=41; DOMAIN=ntp.msn.com");

	web_add_cookie("pglt-edgeChromium-dhp=41; DOMAIN=ntp.msn.com");

	web_add_cookie("sptmarket=en-US||in|en-in|en-in|en||RefA=2F1E55C27B004195A5112589929F7010.RefC=2023-02-13T11:32:59Z; DOMAIN=ntp.msn.com");

	

	web_add_cookie("MSFPC=GUID=c480155e4c9e4d109492c36853f8f075&HASH=c480&LV=202402&V=4&LU=1708756786421; DOMAIN=ntp.msn.com");

	

	

	return 0;
}
