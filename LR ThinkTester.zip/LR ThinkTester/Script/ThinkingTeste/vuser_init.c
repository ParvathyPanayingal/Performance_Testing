/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");
	
	web_reg_find("Text=Contact List App",LAST);
	
	

	web_url("thinking-tester-contact-list.herokuapp.com", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	web_image_check("Image check","Src=/img/thinkingTesterLogo.png");

	/* Home page */

	web_add_cookie("pglt-edgeChromium-ntp=41; DOMAIN=ntp.msn.com");

	web_add_cookie("pglt-edgeChromium-dhp=41; DOMAIN=ntp.msn.com");

	web_add_cookie("sptmarket=en-US||in|en-in|en-in|en||RefA=2F1E55C27B004195A5112589929F7010.RefC=2023-02-13T11:32:59Z; DOMAIN=ntp.msn.com");

	

	web_add_cookie("MSFPC=GUID=c480155e4c9e4d109492c36853f8f075&HASH=c480&LV=202402&V=4&LU=1708756786421; DOMAIN=ntp.msn.com");

	

	web_custom_request("report_2", 
		"URL=https://bzib.nelreports.net/api/report?cat=bingbusiness", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/reports+json", 
		"Body=[{\"age\":222,\"body\":{\"elapsed_time\":99036,\"method\":\"GET\",\"phase\":\"application\",\"protocol\":\"http/1.1\",\"referrer\":\"\",\"sampling_fraction\":1.0,\"server_ip\":\"13.107.6.158\",\"status_code\":401,\"type\":\"http.error\"},\"type\":\"network-error\",\"url\":\"https://business.bing.com/api/v1/user/token/microsoftgraph?&clienttype=edge-omnibox\",\"user_agent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/"
		"121.0.0.0\"}]", 
		LAST);

	

	

	return 0;
}
