/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 0
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_url("thinking-tester-contact-list.herokuapp.com", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	/* Home page */

	web_add_cookie("pglt-edgeChromium-ntp=41; DOMAIN=ntp.msn.com");

	web_add_cookie("pglt-edgeChromium-dhp=41; DOMAIN=ntp.msn.com");

	web_add_cookie("sptmarket=en-US||in|en-in|en-in|en||RefA=2F1E55C27B004195A5112589929F7010.RefC=2023-02-13T11:32:59Z; DOMAIN=ntp.msn.com");

	web_add_cookie("USRLOC=CLOC=LAT=12.9378|LON=77.547|A=10476|TS=240224053952|SRC=I&BID=MjQwMjI0MTEwOTUxXzQ2YzJjNGFkMGMyYTllYWFkYmE1OTNjZjRhNjI1NGI2MTYyNDYxZWZlMTcxZmJiN2RkMjAwZGQ0MmRhNDZmOTE=; DOMAIN=ntp.msn.com");

	web_add_cookie("_EDGE_V=1; DOMAIN=ntp.msn.com");

	web_add_cookie("MUID=3FB288A77D7E6FC13A379A107C2C6E33; DOMAIN=ntp.msn.com");

	web_add_cookie("MicrosoftApplicationsTelemetryDeviceId=15705868-5fea-4f69-93e0-36fa8e3e9a44; DOMAIN=ntp.msn.com");

	web_add_cookie("MUIDB=3FB288A77D7E6FC13A379A107C2C6E33; DOMAIN=ntp.msn.com");

	web_add_cookie("msaoptout=0; DOMAIN=ntp.msn.com");

	web_add_cookie("_SS=SID=00; DOMAIN=ntp.msn.com");

	web_add_cookie("ai_session=YqIBRlE15V5FhIEbySYfUi|1708756782352|1708756782352; DOMAIN=ntp.msn.com");

	web_add_cookie("MSFPC=GUID=c480155e4c9e4d109492c36853f8f075&HASH=c480&LV=202402&V=4&LU=1708756786421; DOMAIN=ntp.msn.com");

	web_url("ntp", 
		"URL=https://ntp.msn.com/edge/ntp?locale=en-US&title=New%20tab&dsp=1&sp=Bing&startpage=1&PC=U531&prerender=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("report", 
		"URL=https://bzib.nelreports.net/api/report?cat=bingbusiness", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("report_2", 
		"URL=https://bzib.nelreports.net/api/report?cat=bingbusiness", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/reports+json", 
		"Body=[{\"age\":222,\"body\":{\"elapsed_time\":99036,\"method\":\"GET\",\"phase\":\"application\",\"protocol\":\"http/1.1\",\"referrer\":\"\",\"sampling_fraction\":1.0,\"server_ip\":\"13.107.6.158\",\"status_code\":401,\"type\":\"http.error\"},\"type\":\"network-error\",\"url\":\"https://business.bing.com/api/v1/user/token/microsoftgraph?&clienttype=edge-omnibox\",\"user_agent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/"
		"121.0.0.0\"}]", 
		LAST);

	web_add_cookie("USRLOC=CLOC=LAT=12.9378|LON=77.547|A=10476|TS=240224053952|SRC=I&BID=MjQwMjI0MTEwOTUxXzQ2YzJjNGFkMGMyYTllYWFkYmE1OTNjZjRhNjI1NGI2MTYyNDYxZWZlMTcxZmJiN2RkMjAwZGQ0MmRhNDZmOTE=; DOMAIN=assets.msn.com");

	web_add_cookie("_EDGE_V=1; DOMAIN=assets.msn.com");

	web_add_cookie("MUID=3FB288A77D7E6FC13A379A107C2C6E33; DOMAIN=assets.msn.com");

	web_add_cookie("MUIDB=3FB288A77D7E6FC13A379A107C2C6E33; DOMAIN=assets.msn.com");

	web_add_cookie("_SS=SID=00; DOMAIN=assets.msn.com");

	web_url("ntp_2", 
		"URL=https://assets.msn.com/service/news/feed/pages/ntp?User=m-3FB288A77D7E6FC13A379A107C2C6E33&activityId=1083F551-87A7-4022-987C-8021B5637AF3&apikey=0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM&audienceMode=adult&caller=bgtask&cm=en-in&column=c3&contentType=article,video,slideshow,webcontent&dhp=1&duotone=true&infopaneCount=17&it=app&memory=8&newsSkip=0&newsTop=48&ocid=anaheim-ntp-feeds&overlay=0&pgc=41&prerender=1&promotion=1697179646278_l_1_2&scn=APP_ANON&timeOut=2000&vpSize=1232x572&wposchema="
		"byregion", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("Rewards", 
		"URL=https://assets.msn.com/service/News/Users/me/Rewards?apikey=1hYoJsIRvPEnSkk0hlnJF2092mHqiz7xFenIFKa9uc&activityId=1083F551-87A7-4022-987C-8021B5637AF3&ocid=rewards-peregrine&cm=en-in&it=app&user=m-3FB288A77D7E6FC13A379A107C2C6E33&scn=APP_ANON&version=2", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("favicon.ico", 
		"URL=https://assets.msn.com/statics/icons/favicon.ico", 
		"Method=HEAD", 
		"Resource=1", 
		"RecContentType=image/x-icon", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t7.inf", 
		LAST);

	web_url("AA2qT4f", 
		"URL=https://assets.msn.com/breakingnews/v1/cms/api/amp/article/AA2qT4f", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://ntp.msn.com/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
